# dlt_inventory/views.py
from django.shortcuts import render
from django.http import JsonResponse
from .crypto_utils import generate_keys, sign_message, verify_signature

# In-memory storage for inventory records
inventory_records = []
consensus_records = []


def index(request):
    return render(request, 'index.html')


def create_record(request):
    if request.method == 'POST':
        item = request.POST.get('item')
        quantity = request.POST.get('quantity')
        owner = request.POST.get('owner')

        private_key, public_key = generate_keys()

        record = {
            'id': len(inventory_records) + 1,
            'item': item,
            'quantity': quantity,
            'owner': owner,
            'signature': sign_message(f"{item}:{quantity}", private_key)
        }

        # Add the record to the inventory and achieve consensus
        consensus_records.append(record)  # Simulate consensus by adding to a list
        inventory_records.append(record)

        return JsonResponse({'message': 'Record created', 'record': record})
    return JsonResponse({'message': 'Invalid request'}, status=400)


def verify_record(request):
    if request.method == 'POST':
        record_id = int(request.POST.get('id'))
        record = next((r for r in inventory_records if r['id'] == record_id), None)

        if record and verify_signature(f"{record['item']}:{record['quantity']}", record['signature'], record['owner']):
            return JsonResponse({'message': 'Record is valid', 'record': record})
        return JsonResponse({'message': 'Record is invalid'}, status=400)

    return JsonResponse({'message': 'Invalid request'}, status=400)


def transfer_record(request):
    if request.method == 'POST':
        record_id = int(request.POST.get('id'))
        new_owner = request.POST.get('new_owner')
        record = next((r for r in inventory_records if r['id'] == record_id), None)

        if record:
            record['owner'] = new_owner
            return JsonResponse({'message': 'Record transferred', 'record': record})
        return JsonResponse({'message': 'Record not found'}, status=404)

