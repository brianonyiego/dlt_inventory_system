# dlt_inventory/urls.py
from django.urls import path
from .views import index, create_record, verify_record, transfer_record

urlpatterns = [
    path('', index, name='index'),
    path('create_record/', create_record, name='create_record'),
    path('verify_record/', verify_record, name='verify_record'),
    path('transfer_record/', transfer_record, name='transfer_record'),
]
